from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.router import api_router
from app.api import reports

app = FastAPI(
    title="GasQ - Queue & Station Management",
    version="0.1.0",
)

# CORS (потом ограничим доменами, сейчас для удобства разработки)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["system"])
def health_check():
    return {"status": "ok", "service": "gasq-backend"}


@app.get("/", tags=["system"])
def root():
    return {"message": "GasQ API is running. Open /docs for Swagger UI."}


# Подключаем все API роуты
app.include_router(api_router)

# Глобальная обработка ошибок (чтобы не падало “молча”)
@app.exception_handler(Exception)
async def global_exception_handler(request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal Server Error", "error": str(exc)},
    )
