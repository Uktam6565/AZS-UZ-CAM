from fastapi import APIRouter

from app.api.stations import router as stations_router
from app.api.pumps import router as pumps_router
from app.api.queue import router as queue_router
from app.api.ratings import router as ratings_router
from app.api.reservations import router as reservations_router
from app.api.routes.notifications import router as notifications_router
from app.api import reports

api_router = APIRouter(prefix="/api")

api_router.include_router(stations_router)
api_router.include_router(pumps_router)
api_router.include_router(queue_router)
api_router.include_router(ratings_router)
api_router.include_router(reservations_router)
api_router.include_router(notifications_router)
api_router.include_router(reports.router)