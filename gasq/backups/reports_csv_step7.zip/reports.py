from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from fastapi.responses import StreamingResponse
import csv
import io

from app.db.session import get_db
from app.models.station import Station
from app.models.queue import QueueTicket

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("/summary", response_model=dict)
async def summary(
    station_id: int,
    date_from: str | None = None,  # YYYY-MM-DD
    date_to: str | None = None,    # YYYY-MM-DD
    db: AsyncSession = Depends(get_db),
):
    station = await db.get(Station, station_id)
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    filters = [QueueTicket.station_id == station_id]

    # --- обработка дат ---
    try:
        if date_from:
            df = datetime.strptime(date_from, "%Y-%m-%d")
            filters.append(QueueTicket.created_at >= df)

        if date_to:
            dt = datetime.strptime(date_to, "%Y-%m-%d")
            dt = dt.replace(hour=23, minute=59, second=59)
            filters.append(QueueTicket.created_at <= dt)

    except ValueError:
        raise HTTPException(
            status_code=400,
            detail="Invalid date format. Use YYYY-MM-DD",
        )

    # --- всего талонов ---
    total_q = await db.execute(
        select(func.count()).where(and_(*filters))
    )
    total = total_q.scalar() or 0

    # --- вызвано ---
    called_q = await db.execute(
        select(func.count()).where(
            and_(*filters, QueueTicket.status == "called")
        )
    )
    called = called_q.scalar() or 0

    # --- ожидают ---
    waiting_q = await db.execute(
        select(func.count()).where(
            and_(*filters, QueueTicket.status == "waiting")
        )
    )
    waiting = waiting_q.scalar() or 0

    # --- среднее ожидание ---
    avg_wait_q = await db.execute(
        select(
            func.avg(
                func.extract(
                    "epoch",
                    QueueTicket.called_at - QueueTicket.created_at
                )
            )
        ).where(
            and_(
                *filters,
                QueueTicket.called_at.isnot(None),
            )
        )
    )
    avg_wait_seconds = avg_wait_q.scalar()

    # --- по топливу ---
    fuel_q = await db.execute(
        select(
            QueueTicket.fuel_type,
            func.count()
        )
        .where(and_(*filters))
        .group_by(QueueTicket.fuel_type)
    )
    by_fuel = {fuel: cnt for fuel, cnt in fuel_q.all()}

    return {
        "station_id": station_id,
        "station_name": station.name,
        "date_from": date_from,
        "date_to": date_to,
        "total_tickets": total,
        "called": called,
        "waiting": waiting,
        "avg_wait_seconds": int(avg_wait_seconds) if avg_wait_seconds else None,
        "by_fuel": by_fuel,
        "generated_at": datetime.utcnow().isoformat(),
    }


@router.get("/export/csv")
async def export_csv(
    station_id: int,
    date_from: str | None = None,  # YYYY-MM-DD
    date_to: str | None = None,    # YYYY-MM-DD
    db: AsyncSession = Depends(get_db),
):
    station = await db.get(Station, station_id)
    if not station:
        raise HTTPException(status_code=404, detail="Station not found")

    filters = [QueueTicket.station_id == station_id]

    # даты
    try:
        if date_from:
            df = datetime.strptime(date_from, "%Y-%m-%d")
            filters.append(QueueTicket.created_at >= df)
        if date_to:
            dt = datetime.strptime(date_to, "%Y-%m-%d") + timedelta(days=1)
            filters.append(QueueTicket.created_at < dt)
    except ValueError:
        raise HTTPException(400, "Invalid date format. Use YYYY-MM-DD")

    q = await db.execute(
        select(QueueTicket).where(and_(*filters)).order_by(QueueTicket.id.asc())
    )
    rows = q.scalars().all()

    buffer = io.StringIO()
    writer = csv.writer(buffer)

    # заголовки
    writer.writerow([
        "ticket_no",
        "fuel_type",
        "status",
        "created_at",
        "called_at",
        "driver_phone",
    ])

    for t in rows:
        writer.writerow([
            t.ticket_no,
            t.fuel_type,
            t.status,
            t.created_at.isoformat() if t.created_at else "",
            t.called_at.isoformat() if t.called_at else "",
            getattr(t, "driver_phone", "") or "",
        ])

    buffer.seek(0)

    filename = f"gasq_report_station_{station_id}_{date_from or 'all'}_{date_to or 'all'}.csv"
    return StreamingResponse(
        buffer,
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )

